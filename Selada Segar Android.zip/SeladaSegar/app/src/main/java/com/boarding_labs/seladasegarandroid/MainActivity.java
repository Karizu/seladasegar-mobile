package com.boarding_labs.seladasegarandroid;

import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.boarding_labs.seladasegarandroid.presentation.HomeFragment;
import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    boolean doubleBackToExitPressedOnce = false;

    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.drawer_layout)
    DrawerLayout drawer;
    @BindView(R.id.nav_view)
    FrameLayout navigationView;

    private ActionBarDrawerToggle toggle;
    private boolean mToolBarNavigationListenerIsRegistered = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        setSupportActionBar(toolbar);
        toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        setOnClickListenerMenu();
        setDefaultFragment();
    }

    private void setOnClickListenerMenu(){
        LinearLayout llFavProduct = findViewById(R.id.ll_fav_product);
        LinearLayout llLogReg = findViewById(R.id.ll_log_reg);
        LinearLayout llLacakPesanan = findViewById(R.id.ll_lacak_pesanan);
        LinearLayout llKontakKami = findViewById(R.id.ll_kontak_kami);
        LinearLayout llMenuUtama = findViewById(R.id.nav_sub_menu_utama);
        LinearLayout llSubKategori = findViewById(R.id.nav_sub_kategori);
        LinearLayout llHome = findViewById(R.id.ll_home);
        LinearLayout llBelanjaSekarang = findViewById(R.id.ll_belanja_sekarang);
        LinearLayout llDaftarProduk = findViewById(R.id.ll_daftar_produk);
        LinearLayout llNavLacakPesanan = findViewById(R.id.ll_nav_lacak_pesanan);
        FrameLayout ll_facebook = findViewById(R.id.nav_facebook);
        FrameLayout ll_instagram = findViewById(R.id.nav_instagram);
        FrameLayout ll_whatsapp = findViewById(R.id.nav_whatsapp);

        llFavProduct.setOnClickListener(view -> {
//            hideAllToolbarIcon();
//            imgNotification.setVisibility(View.VISIBLE);
//            callFragment(new HomeFragment(), null);
        });

        llLogReg.setOnClickListener(view -> {

        });

        llLacakPesanan.setOnClickListener(view -> {

        });

        llKontakKami.setOnClickListener(view -> {

        });

        llMenuUtama.setOnClickListener(view -> {

        });

        llSubKategori.setOnClickListener(view -> {

        });

        llHome.setOnClickListener(view -> {

        });

        llDaftarProduk.setOnClickListener(view -> {

        });

        llLacakPesanan.setOnClickListener(view -> {

        });
    }

    private void hideAllToolbarIcon(){
//        ImageView imgFilter = findViewById(R.id.img_filter_toolbar);
//        RelativeLayout imgNotification = findViewById(R.id.img_notification_toolbar);
//        ImageView imgQrCode = findViewById(R.id.img_qr_code_toolbar);
//        ImageView imgSetting = findViewById(R.id.img_setting_toolbar);
//        ImageView imgShare = findViewById(R.id.img_share_toolbar);

//        imgFilter.setVisibility(View.GONE);
//        imgNotification.setVisibility(View.GONE);
//        imgQrCode.setVisibility(View.GONE);
//        imgSetting.setVisibility(View.GONE);
//        imgShare.setVisibility(View.GONE);
    }

    private void callFragment(@NonNull Fragment fragment, Bundle bundle){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        if (bundle !=null)
            fragment.setArguments(bundle);

        fragmentTransaction.replace(R.id.screen_area, fragment);
        fragmentTransaction.commit();

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
    }

    @Override
    public void onBackPressed() {
        if (getSupportFragmentManager().getBackStackEntryCount() == 1){
            showBackMenu(false);
        }
        if (getSupportFragmentManager().getBackStackEntryCount() > 0){
            getSupportFragmentManager().popBackStack();
        } else {
            if (doubleBackToExitPressedOnce) {
                super.onBackPressed();
                return;
            }

            this.doubleBackToExitPressedOnce = true;
            Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

            new Handler().postDelayed(() -> doubleBackToExitPressedOnce=false, 2000);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.navigation_drawer, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        Fragment fragment = null;

        if (id == R.id.nav_home) {
            fragment = new HomeFragment();
        } else if (id == R.id.nav_forum_diskusi) {
            fragment = new HomeFragment();
        } else if (id == R.id.nav_berita_pengumuman) {
            fragment = new HomeFragment();
        } else if (id == R.id.nav_direktori_anggota) {
            fragment = new HomeFragment();
        } else if (id == R.id.nav_artikel) {
            fragment = new HomeFragment();
        } else if (id == R.id.nav_kalender_kegiatan) {
            fragment = new HomeFragment();
        } else if (id == R.id.nav_setting) {
            fragment = new HomeFragment();
        }

        if (fragment != null){
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

            fragmentTransaction.replace(R.id.screen_area, fragment);
            fragmentTransaction.addToBackStack("Home Fragment");

            fragmentTransaction.commit();
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void setDefaultFragment(){
        Fragment fragment = new HomeFragment();
        if (fragment != null){
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.screen_area, fragment);
            fragmentTransaction.commit();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
    }

    public void showBackMenu(boolean enable) {
        if(enable) {
            drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
            toggle.setDrawerIndicatorEnabled(false);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            if(!mToolBarNavigationListenerIsRegistered) {
                toggle.setToolbarNavigationClickListener(v -> onBackPressed());
                mToolBarNavigationListenerIsRegistered = true;
            }
        } else {
            drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            toggle.setDrawerIndicatorEnabled(true);
            toggle.setToolbarNavigationClickListener(null);
            mToolBarNavigationListenerIsRegistered = false;
        }
    }
}